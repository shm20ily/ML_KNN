import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# 加载字体
plt.rcParams['font.sans-serif'] = ['SimHei'] # 指定默认字体
# 显示负号
plt.rcParams['axes.unicode_minus'] = False


class Myknn(object):
    def __init__(self, train_df, k):
        """
        :param train_df: 训练数据
        :param k: 近邻点个数
        """
        self.train_df = train_df
        self.k = k

    def predict(self, test_df):
        """预测函数"""
        # 计算欧式距离
        self.train_df['距离'] = np.sqrt(
            (test_df['多云'] - self.train_df['多云']) ** 2 + (test_df['雨'] - self.train_df['雨']) ** 2)
        # 按距离排序 前K个数据的类别
        my_types = self.train_df.sort_values(by='距离').iloc[:self.k]['天气情况']
        print(my_types)

        my_type = my_types.value_counts().index[0]
        print(my_type)


# 读取数据
my_df = pd.read_excel('八九月数据.xlsx', sheet_name=0)
my_df.set_index('11月份', inplace=True)
# print(my_df.shape)

# 训练数据  特征:多云 雨 类别：天气情况
train_df = my_df.loc[:31, ["多云", "雨", "天气情况"]]
# print(train_df)
# 预测数据
test_df_1 = my_df.loc[32, ["多云", "雨"]]    # 11月份1号
test_df_5 = my_df.loc[36, ["多云", "雨"]]    # 11月份5号
test_df_9 = my_df.loc[40, ["多云", "雨"]]    # 11月份9号
# print(test_df_1)
x = train_df.index.tolist()
y1 = train_df.iloc[:, 0].values.tolist()
y2 = train_df.iloc[:, 1].values.tolist()
label = train_df.iloc[:, -1].values.tolist()
# print(x)
# print(y1)
# print(y2)
# print(label)
# print(train_df.shape)
# print(test_df.shape)

# fig = plt.figure(figsize=(10, 6))
# # 绘图--训练集多云天气趋势
# plt.plot(x,  # x轴数据
#          y1,  # y轴数据
#          linestyle='-',  # 折线类型
#          linewidth=2,  # 折线宽度
#          color='steelblue',  # 折线颜色
#          marker='o',  # 点的形状
#          markersize=6,  # 点的大小
#          markeredgecolor='black',  # 点的边框色
#          markerfacecolor='steelblue',  # 点的填充色
#          label='多云')  # 添加标签
#
# # 绘图--训练集雨天气趋势
# plt.plot(x,  # x轴数据
#          y2,  # y轴数据
#          linestyle='-',  # 折线类型
#          linewidth=2,  # 折线宽度
#          color='#ff9999',  # 折线颜色
#          marker='o',  # 点的形状
#          markersize=6,  # 点的大小
#          markeredgecolor='black',  # 点的边框色
#          markerfacecolor='#ff9999',  # 点的填充色
#          label='雨')  # 添加标签
# # 添加标题
# plt.title('11月份训练集天气趋势图')
# # 添加坐标轴标签
# plt.xlabel('日期')
# plt.xticks(x)
#
# plt.tight_layout()
# # 显示图例
# plt.legend()
# # 显示图形
# plt.show()

# 算法实现
mk = Myknn(train_df, 3)
print('-' * 15 + '11月份1号')
mk.predict(test_df_1)
print('-' * 15 + '11月份5号')
mk.predict(test_df_5)
print('-' * 15 + '11月份9号')
mk.predict(test_df_9)
