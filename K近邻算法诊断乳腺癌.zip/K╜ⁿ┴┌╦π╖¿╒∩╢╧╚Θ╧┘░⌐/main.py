import pandas as pd

breast_cancer = pd.read_csv("wisc_bc_data.csv")
# print(breast_cancer.shape)
breast_cancer.head(10)

del breast_cancer["id"]

# print(breast_cancer.diagnosis.value_counts())
# print(breast_cancer.diagnosis.value_counts() / len(breast_cancer))

dignosis_dict = {"B": 0, "M": 1}
breast_cancer["diagnosis"] = breast_cancer["diagnosis"].map(dignosis_dict)

# print(breast_cancer[["radius_mean", "area_mean", "smoothness_mean"]].describe())


def min_max_normalize(x):
    return (x - x.min()) / (x.max() - x.min())


for col in breast_cancer.columns[1:31]:
    breast_cancer[col] = min_max_normalize(breast_cancer[col])

# print(breast_cancer.iloc[:, 1:].describe())

from sklearn.model_selection import train_test_split

y = breast_cancer['diagnosis']
del breast_cancer['diagnosis']
X = breast_cancer
breast_cancer_minmax_train, breast_cancer_minmax_test, \
breast_cancer_train_labels, breast_cancer_test_labels \
    = train_test_split(X, y, test_size=0.3, random_state=0)

# print(breast_cancer_train_labels.value_counts() / len(breast_cancer_train_labels))
# print(breast_cancer_test_labels.value_counts() / len(breast_cancer_test_labels))

from sklearn.neighbors import KNeighborsClassifier

knn_model = KNeighborsClassifier(n_neighbors=21)
knn_model.fit(breast_cancer_minmax_train, breast_cancer_train_labels)

breast_cancer_test_pred = knn_model.predict(breast_cancer_minmax_test)

from sklearn import metrics

# print(metrics.classification_report(breast_cancer_test_labels, breast_cancer_test_pred))
# print(metrics.confusion_matrix(breast_cancer_test_labels, breast_cancer_test_pred))
# print(metrics.accuracy_score(breast_cancer_test_labels, breast_cancer_test_pred))


k_list = (1, 5, 9, 11, 15, 21, 27)
for k in k_list:
    knn_model = KNeighborsClassifier(n_neighbors=k)
    knn_model.fit(breast_cancer_minmax_train, breast_cancer_train_labels)

    breast_cancer_test_pred = knn_model.predict(breast_cancer_minmax_test)
    accuracy = metrics.accuracy_score(breast_cancer_test_labels, breast_cancer_test_pred)
    confusion_mat = metrics.confusion_matrix(breast_cancer_test_labels, breast_cancer_test_pred)

    # print("k = ", k)
    # print("\t正确率: ", '%.2f' % (accuracy * 100) + "%")
    # print("\t假阴性：", confusion_mat[0, 1])
    # print("", "\t假阳性：", confusion_mat[1, 0])

from sklearn import preprocessing

breast_cancer_zscore = pd.DataFrame(preprocessing.scale(breast_cancer), columns=breast_cancer.columns)
breast_cancer_zscore.head(5)

# print(breast_cancer_zscore.area_mean.mean())
# print(breast_cancer_zscore.area_mean.std())

breast_cancer_zscore_train, breast_cancer_zscore_test, \
breast_cancer_train_labels, breast_cancer_test_labels \
    = train_test_split(breast_cancer_zscore, y, test_size=0.3, random_state=0)

# 模型训练
knn_model_z = KNeighborsClassifier(n_neighbors=5)
knn_model_z.fit(breast_cancer_zscore_train, breast_cancer_train_labels)
# 模型预测
breast_cancer_test_pred_z = knn_model_z.predict(breast_cancer_zscore_test)
# 性能评估
accuracy_z = metrics.accuracy_score(breast_cancer_test_labels, breast_cancer_test_pred_z)
confusion_mat_z = metrics.confusion_matrix(breast_cancer_test_labels, breast_cancer_test_pred_z)

# print("k = 5")
# print("\t正确率: ", '%.2f' % (accuracy_z * 100) + "%")
# print("\t假阴性：", confusion_mat_z[0, 1])
# print("", "\t假阳性：", confusion_mat_z[1, 0])
